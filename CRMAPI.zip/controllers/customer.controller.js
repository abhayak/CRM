const CRM = require("../models/customer.model.js");

// Create and Save a new Customer
exports.clientAdd = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Customer
  const client = new CRM({
    hw:'',
    CompanyName:req.body.CompanyName,
    FirstName:req.body.FirstName,
    LastName:req.body.LastName,
    Phone:req.body.Phone,
    Email:req.body.Email,
    Category:req.body.Category,
    Address1:req.body.Address1,
    Address2:req.body.Address2,
    Country:req.body.Country,
    State:req.body.State,
    City:req.body.City,
    ZipCode:req.body.ZipCode,
    active:req.body.active,
    processRecurrings:req.body.processRecurrings,
    adminFlag:req.body.adminFlag,
    duplicateCheck:req.body.duplicateCheck,
    user:req.body.username,
    pass:req.body.password
  });
  //  console.log(cleint);
   
  //  Save Customer in the database
  CRM.addClient(client, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Customer."
      });
    else res.send(data);
  });
};
exports.clientKeyAdd=(req,res)=>{
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  const clientKey = new CRM({
    keyName:req.body.keyName,
    keyType:req.body.keyType,
    client_id:req.body.client_id,
  })
  CRM.clientkeyMAdd(clientKey,(err,data)=>{
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Customer."
      });
    else 
   res.send(data);
  })
}
exports.clientUpdate = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Customer
  const client = new CRM({
    CompanyName:req.body.CompanyName,
    id:req.body.id,
    FirstName:req.body.FirstName,
    LastName:req.body.LastName,
    Phone:req.body.Phone,
    Email:req.body.Email,
    Category:req.body.Category,
    Address1:req.body.Address1,
    Address2:req.body.Address2,
    Country:req.body.Country,
    State:req.body.State,
    City:req.body.City,
    ZipCode:req.body.ZipCode,
    active:req.body.active,
    processRecurrings:req.body.processRecurrings,
    adminFlag:req.body.adminFlag,
    duplicateCheck:req.body.duplicateCheck,
  });
  //  console.log(cleint);
   
  //  Save Customer in the database
  CRM.updateClient(client, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Customer."
      });
    else res.send(data);
  });
};
// Retrieve all Customers from the database.
exports.countryAll = (req, res) => {
  CRM.getCAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving customers."
      });
    else res.send(data);
  });
};
exports.stateAllE = (req, res) => {
  CRM.stateMAllE((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving customers."
      });
    else res.send(data);
  });
};
exports.stateAll =(req, res)=> {
  CRM.getSAll(req.params.countryId,(err, data) => {
    if (err) {
            if (err.kind === "not_found") {
              res.status(404).send({
                message: `Not found Customer with id ${req.params.countryId}.`
              });
            } else {
              res.status(500).send({
                message: "Error retrieving Customer with id " + req.params.countryId
              });
            }
          } else res.send(data);
  });
}
exports.clientList=(req,res)=>{
  CRM.clientMList((err, data) => {
    if (err) {
            if (err.kind === "not_found") {
              res.status(404).send({
                message: `Not found Customer with id.`
              });
            } else {
              res.status(500).send({
                message: "Error retrieving Customer with id " + req.params.countryId
              });
            }
          } else res.send(data);
  });
}
exports.clientListOne =(req, res)=> {
  CRM.clientMListOne(req.params.clientid,(err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(204).send({status:`404`,
          message: `Not found Customer with id ${req.params.countryId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Customer with id " + req.params.countryId
        });
      }
    } else {
      var key=[];
      var object_client;
      data.forEach(datas => {
        key.push({'client_id':datas.id,'client_key':datas.client_key});
      })
      object_client = { 
        clientInfo: data[0],  
        clientKey:key
     };
      // console.log(object_client);
      res.send(object_client);
    }
  });
}
exports.userAuth =(req, res)=>{
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  // Create a Customer
  const user= new CRM({
    user:req.body.username,
    pass:req.body.password
  });
  CRM.UserAuth( user, (err,data) =>{
    // console.log(user);
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving customers."
      });
    else res.send(data);
  })
}
// // Find a single Customer with a customerId
// exports.findOne = (req, res) => {
//   Customer.findById(req.params.customerId, (err, data) => {
//     if (err) {
//       if (err.kind === "not_found") {
//         res.status(404).send({
//           message: `Not found Customer with id ${req.params.customerId}.`
//         });
//       } else {
//         res.status(500).send({
//           message: "Error retrieving Customer with id " + req.params.customerId
//         });
//       }
//     } else res.send(data);
//   });
// };

// // Update a Customer identified by the customerId in the request
// exports.update = (req, res) => {
//   // Validate Request
//   if (!req.body) {
//     res.status(400).send({
//       message: "Content can not be empty!"
//     });
//   }

//   console.log(req.body);

//   Customer.updateById(
//     req.params.customerId,
//     new Customer(req.body),
//     (err, data) => {
//       if (err) {
//         if (err.kind === "not_found") {
//           res.status(404).send({
//             message: `Not found Customer with id ${req.params.customerId}.`
//           });
//         } else {
//           res.status(500).send({
//             message: "Error updating Customer with id " + req.params.customerId
//           });
//         }
//       } else res.send(data);
//     }
//   );
// };

// // Delete a Customer with the specified customerId in the request
exports.clientKeyDeleteAdd = (req, res) => {
  CRM.clientKeyMDeleteAdd(req.params.clientkeyId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.customerId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Customer with id " + req.params.customerId
        });
      }
    } else res.send({ message: `Customer was deleted successfully!` });
  });
};

// // Delete all Customers from the database.
// exports.clientKeyDeleteAdd = (req, res) => {
//   CRM.clientKeyMDeleteAdd((err, data) => {
//     if (err)
//       res.status(500).send({
//         message:
//           err.message || "Some error occurred while removing all customers."
//       });
//     else res.send({ message: `All Customers were deleted successfully!` });
//   });
// };
const sql = require("./db.js");
const jwt = require('jwt-simple');
const crypto = require('crypto');
const db = 'crm_';
const db1 = 'ox_';
const key = crypto.randomBytes(32);
const iv = crypto.randomBytes(16);

function encrypt(text) {
 let cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);
 let encrypted = cipher.update(text);
 encrypted = Buffer.concat([encrypted, cipher.final()]);
 return { iv: iv.toString('hex') , encryptedData: encrypted.toString('hex')  };
}

// function decrypt(text) {
//  let iv = Buffer.from(text.iv, 'hex');
//  let encryptedText = Buffer.from(text.encryptedData, 'hex');
//  let decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(key), iv);
//  let decrypted = decipher.update(encryptedText);
//  decrypted = Buffer.concat([decrypted, decipher.final()]);
//  return decrypted.toString();
// }
// if()
var date= new Date();
date=  date.getTime();
  var hw = encrypt(Buffer.from('decrypted',"utf-8"))

const CRM = function(CRMS) {
  this.CompanyName=CRMS.CompanyName,
  this.id=CRMS.id,
  this.first_name=CRMS.FirstName,
  this.last_name=CRMS.LastName,
  this.phone_number=CRMS.Phone,
  this.email=CRMS.Email,
  this.Category=CRMS.Category,
  this.address_line_1=CRMS.Address1,
  this.address_line_2=CRMS.Address2,
  this.country_id=CRMS.Country,
  this.state_id=CRMS.State,
  this.City=CRMS.City,
  this.zip_code=CRMS.ZipCode,
  this.active=CRMS.active,
  // this.active=CRMS .active,
  this.processRecurrings=CRMS .processRecurrings,
  this.adminFlag=CRMS .adminFlag,
  this.duplicateCheck=CRMS .duplicateCheck,
  this.username=CRMS.user,
  this.password=CRMS.pass,
  this.keyName=CRMS.keyName,
  this.keyType=CRMS.keyType,
  this.client_id=CRMS.client_id
};
CRM.addClient = (CRMSC, result) => {
  // console.log(CRMSC); 
  // console.log(hw.iv); 
  sql.query('INSERT INTO '+db+'clients (company_name,first_name,last_name, phone_number, email, address_line_1, address_line_2,category_name,country_id,city,state_id,zip_code,active,process_recurrings,admin_flag,duplicate_check)'
  + 'VALUES ("'+CRMSC.CompanyName+'","'+CRMSC.first_name+'","'+CRMSC.last_name+'", "'+CRMSC.phone_number+'", "'+CRMSC.email+'", "'+CRMSC.address_line_1+'", "'+CRMSC.Category+'","'+CRMSC.address_line_2+'",  "'+CRMSC.country_id+'","'+CRMSC.City+'", "'+CRMSC.state_id+'", "'+CRMSC.zip_code+'",'+true+','+false+','+false+','+false+')' , (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    sql.query('INSERT INTO '+db+'client_key (client_key,active,key_type,client_id,created_on) VALUES ("secret_c'+hw.encryptedData+'",'+true+',"key_type","'+res.insertId+'",NOW())', (err, res) =>{
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }
      // console.log('INSERT INTO client_key (client_key,active,key_type,client_id) VALUES ("secret_c'+hw.iv+'",'+true+',"key_type","'+res.insertId+'")');
      result(null, { 'status': '1' });
    })
    // console.log("created customer: ", { id: res.insertId, ...CRMSC });
    // // result(null, { id: res.insertId, ...newCustomer });
    // result(null, { 'status': '1' });
  });
};
CRM.clientkeyMAdd=(CRMSC, result)=>{
  console.log(CRMSC); 

  sql.query('INSERT INTO '+db+'client_key (client_key,active,key_type,client_id,created_on) VALUES ("secret_c'+hw.encryptedData+'",'+true+',"'+CRMSC.keyType+'","'+CRMSC.client_id+'",NOW())', (err, res) =>{
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    // console.log('INSERT INTO client_key (client_key,active,key_type,client_id) VALUES ("secret_c'+hw.iv+'",'+true+',"key_type","'+res.insertId+'")');
    result(null, { 'status': '1' });
  })
}
CRM.updateClient = (CRMSC, result) => {
  console.log(CRMSC);
  
  sql.query('UPDATE  '+db+'clients SET company_name="'+CRMSC.CompanyName+'", first_name="'+CRMSC.first_name+'",last_name="'+CRMSC.last_name+'", phone_number="'+CRMSC.phone_number+'", email="'+CRMSC.email+'", address_line_1="'+CRMSC.address_line_1+'", address_line_2="'+CRMSC.address_line_2+'",country_id="'+CRMSC.country_id+'",city="'+CRMSC.City+'",category_name="'+CRMSC.Category+'",state_id="'+CRMSC.state_id+'",zip_code="'+CRMSC.zip_code+'", active='+CRMSC.active+', process_recurrings='+CRMSC.processRecurrings+', admin_flag='+CRMSC.adminFlag+', duplicate_check='+CRMSC.duplicateCheck+' WHERE id = "'+CRMSC.id+'"',
 (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    // console.log("created customer: ", { id: res.insertId, ...CRMSC });
    // result(null, { id: res.insertId, ...newCustomer });
    result(null, { 'status': '1' });

  });
};
// Customer.findById = (customerId, result) => {
//   sql.query(`SELECT * FROM hr_country WHERE id = ${customerId}`, (err, res) => {
//     if (err) {
//       console.log("error: ", err);
//       result(err, null);
//       return;
//     }
//     if (res.length) {
//       console.log("found customer: ", res[0]);
//       result(null, res[0]);
//       return;
//     }
//     // not found Customer with the id
//     result({ kind: "not_found" }, null);
//   });
// };
CRM.getCAll = result => {
  sql.query("SELECT * FROM "+db1+"country", (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};
CRM.stateMAllE = result => {
  sql.query("SELECT * FROM "+db1+"state", (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};
CRM.getSAll = (countryId, result) => {
   sql.query(`SELECT * FROM `+db1+`state WHERE country_id = ${countryId}`, (err, res) => {
    if (err) {
      result(err, null);
      return;
    }
    if (res.length) {
      result(null, res);
      return;
    }
    result({ kind: "not_found" }, null);
  });
};
CRM.clientMList= result => {
  sql.query("SELECT * FROM "+db+"clients", (err, res) => {
    if (err) {
      result(null, err);
      return;
    }
    result(null, res);
  });
};
CRM.clientMListOne = (clientid, result) => {
  sql.query(`SELECT * FROM `+db+`clients INNER JOIN `+db+`client_key ON `+db+`client_key.client_id=`+db+`clients.id WHERE `+db+`clients.id = ${clientid}`, (err, res) => {
   if (err) {
     result(err, null);
     return;
   }
   if (res.length) {
     result(null, res);
     return;
   }
   result({ kind: "not_found" }, null);
 });
};
CRM.UserAuth=(CRML, result) =>{
  // console.log(`SELECT * FROM ax_user clientMListOne  user_name=\'`+CRML.username+`\' AND password=\'`+CRML.password+`\'`);
  
  sql.query('SELECT * FROM ax_user WHERE user_name ="'+CRML.username+'" AND password ="'+CRML.password+'"', (err, res) => {
    if (err) {
      result(err, null);
      console.log(err);

      return;
    }
    if(res){
      // console.log(res);
    if(res.length>0){
        var payload = { uid: CRML.username };
        var secret = 'xxx';
        var token = jwt.encode(payload, secret);
        var tokens = jwt.decode(token, secret);
        result(null,{'token': token});
        // console.log(token);
        return;
      }
      else{
        result(null,{"code":204,"success":"username and password does not match"}); 
        // console.log('token');
        return;
      }
      }
    // result({ kind: "not_found" }, null);
  });   
};

// Customer.updateById = (id, customer, result) => {
//   sql.query(
//     "UPDATE customers SET email = ?, name = ?, active = ? WHERE id = ?",
//     [customer.email, customer.name, customer.active, id],
//     (err, res) => {
//       if (err) {
//         console.log("error: ", err);
//         result(null, err);
//         return;
//       }

//       if (res.affectedRows == 0) {
//         // not found Customer with the id
//         result({ kind: "not_found" }, null);
//         return;
//       }

//       console.log("updated customer: ", { id: id, ...customer });
//       result(null, { id: id, ...customer });
//     }
//   );
// };

CRM.clientKeyMDeleteAdd = (id, result) => {
  sql.query("DELETE FROM "+db+"client_key WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }
    console.log("deleted customer with id: ", id);
    result(null, res);
  });
};

// Customer.removeAll = result => {
//   sql.query("DELETE FROM customers", (err, res) => {
//     if (err) {
//       console.log("error: ", err);
//       result(null, err);
//       return;
//     }






//     console.log(`deleted ${res.affectedRows} customers`);
//     result(null, res);
//   });
// };

module.exports = CRM;

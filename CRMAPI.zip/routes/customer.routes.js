module.exports = app => {
    const CRM = require("../controllers/customer.controller.js");
    // Create a new Customer
    // app.post("/customers", customers.create);
  
    // Retrieve all Customers
    app.get("/country", CRM.countryAll);
    app.get("/state", CRM.stateAllE);
    app.get("/state/:countryId", CRM.stateAll);
    app.get("/clientlist", CRM.clientList);
    app.get("/clientlist/:clientid", CRM.clientListOne);
    app.post("/clientadd", CRM.clientAdd);
    app.post("/clientupdate", CRM.clientUpdate);
    app.post("/users/authenticate",CRM.userAuth);
    app.post("/clientkeyadd",CRM.clientKeyAdd);
    app.delete("/clientkeydeleteadd/:clientkeyId",CRM.clientKeyDeleteAdd);
    // app.post("/clientkeystatusadd",CRM.clientKeyStatusAdd);

  
    // Retrieve a single Customer with customerId
    // app.get("/customers/:customerId", customers.findOne);
  
    // Update a Customer with customerId
    // app.put("/customers/:customerId", customers.update);
  
    // Delete a Customer with customerId
    // app.delete("/customers/:customerId", customers.delete);
  
    // Create a new Customer
    // app.delete("/customers", customers.deleteAll);
  };
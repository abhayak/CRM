const express = require("express");
const bodyParser = require("body-parser");
const cors = require('cors');
const app = express();
const crypto = require('crypto');

// parse requests of content-type - application/json
app.use(bodyParser.json());
app.use(cors());
// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
// simple route
app.get("/", (req, res) => {

// const key = crypto.randomBytes(32);
// const iv = crypto.randomBytes(16);

// const key = crypto.randomBytes(32);
// const iv = crypto.randomBytes(16);

// function encrypt(text) {
//  let cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);
//  let encrypted = cipher.update(text);
//  encrypted = Buffer.concat([encrypted, cipher.final()]);
//  return { iv: iv.toString('hex'), encryptedData: encrypted.toString('hex') };
// }

// function decrypt(text) {
//  let iv = Buffer.from(text.iv, 'hex');
//  let encryptedText = Buffer.from(text.encryptedData, 'hex');
//  let decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(key), iv);
//  let decrypted = decipher.update(encryptedText);
//  decrypted = Buffer.concat([decrypted, decipher.final()]);
//  return decrypted.toString();
// }
// var hw = encrypt(Buffer.from("defaultkey","utf-8"))

// console.log(hw)
// console.log(decrypt(hw))
// constructor



  res.json({ message: "Welcome to Amayax infotech application." });
});


require("./routes/customer.routes.js")(app);

// set port, listen for requests
const PORT = process.env.PORT || 3600;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
// 0e29b88c500143f9a710072d181cf2a4